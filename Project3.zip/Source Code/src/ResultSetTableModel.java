/*
Name: Isabel Barragan
Course: CNT 4714 Spring 2026
Assignment title: Project 3 – A Result Set Table Application Model
Date: March 15, 2026
Class: ResultSetTableModel
*/


import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.table.AbstractTableModel;

@SuppressWarnings({"serial", "rawtypes", "unchecked"})
public class ResultSetTableModel extends AbstractTableModel {

    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;
    private ResultSetMetaData metaData;
    private int numberOfRows;

    // Keep track of the database connection status
    private boolean connectedToDatabase = false;

    // Constructor, connection is passed in from the GUI app
    public ResultSetTableModel(Connection conn) throws SQLException {
        connection = conn;
        // create statement to query the database
        statement = connection.createStatement(
                ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        connectedToDatabase = true;
    }

    // Get class that represents column type
	public Class getColumnClass(int column) throws IllegalStateException {
        if (!connectedToDatabase)
            throw new IllegalStateException("Not Connected to Database");
        try {
            String className = metaData.getColumnClassName(column + 1);
            return Class.forName(className);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return Object.class;
    }

    // Get number of columns in ResultSet
    public int getColumnCount() throws IllegalStateException {
        if (!connectedToDatabase)
            throw new IllegalStateException("Not Connected to Database");
        try {
            return metaData.getColumnCount();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return 0;
    } 

    // Get name of a particular column in ResultSet
    public String getColumnName(int column) throws IllegalStateException {
        if (!connectedToDatabase)
            throw new IllegalStateException("Not Connected to Database");
        try {
            return metaData.getColumnName(column + 1);
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return "";
    }

    // Return number of rows in ResultSet
    public int getRowCount() throws IllegalStateException {
        if (!connectedToDatabase)
            throw new IllegalStateException("Not Connected to Database");
        return numberOfRows;
    }

    // Get the value in the rows and columns
    public Object getValueAt(int row, int column) throws IllegalStateException {
        if (!connectedToDatabase)
            throw new IllegalStateException("Not Connected to Database");
        try {
            resultSet.next(); 
            resultSet.absolute(row + 1);
            return resultSet.getObject(column + 1);
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return "";
    }

    // Set new database query string for select statements
    public void setQuery(String query) throws SQLException, IllegalStateException {
        if (!connectedToDatabase)
            throw new IllegalStateException("Not Connected to Database");

        // Specify the query and execute it
        resultSet = statement.executeQuery(query);

        // Get the meta data for ResultSet
        metaData = resultSet.getMetaData();

        // Determine the number of rows in ResultSet
        resultSet.last();              
        numberOfRows = resultSet.getRow(); 

        // Notify to the JTable that the model has changed
        fireTableStructureChanged();
    }

    // Set new database update, returns the rows that it applied to 
    public int setUpdate(String query) throws SQLException, IllegalStateException {
        if (!connectedToDatabase)
            throw new IllegalStateException("Not Connected to Database");

        int res = statement.executeUpdate(query);
        return res;
    }

    // Close statement only, connection is owned by the GUI
    public void disconnectFromDatabase() {
        if (!connectedToDatabase)
            return;
        try {
            statement.close();
            // Reminder Isabel: do not close the connection here, the GUI app does all of that 
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } finally {
            connectedToDatabase = false;
        }
    }

    public boolean isConnected() {
        return connectedToDatabase;
    }
} 
