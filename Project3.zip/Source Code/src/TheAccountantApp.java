/*
Name: Isabel Barragan
Course: CNT 4714 Spring 2026
Assignment title: Project 3 – A Specialized Accountant Application
Date: March 15, 2026
Class: TheAccountantApp
*/


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.sql.*;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;
import com.mysql.cj.jdbc.MysqlDataSource;

@SuppressWarnings({"serial", "unused"})
public class TheAccountantApp extends JFrame {

    // Hardcoded — the accountant always uses these files, no dropdown will be needed
    private static final String ACCOUNTANT_PROPS_FILE  = "theaccountant.properties";
    private static final String OPERATIONSLOG_PROPS_FILE = "operationslog.properties";

    // GUI components 
    private JTextField   usernameField  = new JTextField(12);
    private JPasswordField passwordField = new JPasswordField(12);

    private JButton connectButton     = new JButton("Connect to Database");
    private JButton disconnectButton  = new JButton("Disconnect From Database");
    private JButton executeButton     = new JButton("Execute SQL Command");
    private JButton clearCmdButton    = new JButton("Clear SQL Command");
    private JButton clearResultButton = new JButton("Clear Result Window");
    private JButton closeButton       = new JButton("Close Application");

    private JLabel connectionStatusLabel = new JLabel("  NO CONNECTION ESTABLISHED  ");

    private JTextArea sqlCommandArea = new JTextArea(5, 60);
    private JTable    resultTable    = new JTable();
    private TableModel emptyModel   = new DefaultTableModel();

    // Active database connection 
    private Connection connection = null;

    // Constructor
    public TheAccountantApp() {
        super("ACCOUNTANT APPLICATION  – (CNT 4714 – Spring 2026 – Project 3)");

        buildGUI();
        wireButtons();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setResizable(false);
        setVisible(true);
    }

    // Build the GUI layout it basically mirrors SQLClientApp but without the dropdown menu
    private void buildGUI() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setPreferredSize(new Dimension(980, 780));
        mainPanel.setBackground(Color.LIGHT_GRAY);

        // DB Connection area panel 
        JPanel connPanel = new JPanel(null);
        connPanel.setBackground(Color.LIGHT_GRAY);
        connPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.RED, 2),
            "DB Connection area",
            javax.swing.border.TitledBorder.LEFT,
            javax.swing.border.TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 11), Color.RED));
        connPanel.setBounds(5, 5, 968, 175);
        mainPanel.add(connPanel);

        // Connection Details header
        JLabel connDetailsLabel = new JLabel("Connection Details", SwingConstants.CENTER);
        connDetailsLabel.setFont(new Font("Arial", Font.BOLD, 13));
        connDetailsLabel.setForeground(new Color(0, 100, 200));
        connDetailsLabel.setBounds(270, 14, 220, 20);
        connPanel.add(connDetailsLabel);

        // DB URL Properties it is a read-only display field (hardcoded)
        JLabel dbUrlLabel = new JLabel("DB URL Properties");
        dbUrlLabel.setFont(new Font("Arial", Font.BOLD, 11));
        dbUrlLabel.setBounds(10, 25, 140, 18);
        connPanel.add(dbUrlLabel);

        JTextField dbUrlDisplay = new JTextField("operationslog.properties");
        dbUrlDisplay.setEditable(false);
        dbUrlDisplay.setBackground(Color.WHITE);
        dbUrlDisplay.setBounds(10, 43, 200, 24);
        connPanel.add(dbUrlDisplay);

        // User Properties it is a read-only display field (hardcoded)
        JLabel userPropsLabel = new JLabel("User Properties");
        userPropsLabel.setFont(new Font("Arial", Font.BOLD, 11));
        userPropsLabel.setBounds(220, 25, 140, 18);
        connPanel.add(userPropsLabel);

        JTextField userPropsDisplay = new JTextField("theaccountant.properties");
        userPropsDisplay.setEditable(false);
        userPropsDisplay.setBackground(Color.WHITE);
        userPropsDisplay.setBounds(220, 43, 200, 24);
        connPanel.add(userPropsDisplay);

        // Username and password fields
        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 11));
        usernameLabel.setBounds(10, 78, 80, 18);
        connPanel.add(usernameLabel);

        usernameField.setBounds(10, 96, 190, 24);
        connPanel.add(usernameField);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 11));
        passwordLabel.setBounds(220, 78, 80, 18);
        connPanel.add(passwordLabel);

        passwordField.setBounds(220, 96, 190, 24);
        connPanel.add(passwordField);

        // Connect and disconnect buttons
        styleButton(connectButton,    new Color(0, 0, 200), Color.WHITE);
        styleButton(disconnectButton, new Color(180, 0, 0), Color.WHITE);
        connectButton.setBounds(740, 25, 210, 28);
        disconnectButton.setBounds(740, 60, 210, 28);
        connPanel.add(connectButton);
        connPanel.add(disconnectButton);

        // Connection status
        JLabel statusHeader = new JLabel("CONNECTION STATUS", SwingConstants.CENTER);
        statusHeader.setFont(new Font("Arial", Font.BOLD, 11));
        statusHeader.setBounds(740, 93, 210, 18);
        connPanel.add(statusHeader);

        connectionStatusLabel.setFont(new Font("Arial", Font.BOLD, 11));
        connectionStatusLabel.setForeground(Color.WHITE);
        connectionStatusLabel.setBackground(new Color(180, 0, 0));
        connectionStatusLabel.setOpaque(true);
        connectionStatusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        connectionStatusLabel.setBounds(530, 113, 425, 28);
        connPanel.add(connectionStatusLabel);

        // SQL Command Input Window 
        JLabel cmdLabel = new JLabel("SQL Command Input Window", SwingConstants.CENTER);
        cmdLabel.setFont(new Font("Arial", Font.BOLD, 12));
        cmdLabel.setForeground(new Color(0, 100, 200));
        cmdLabel.setBounds(5, 178, 968, 20);
        mainPanel.add(cmdLabel);

        sqlCommandArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        sqlCommandArea.setLineWrap(true);
        sqlCommandArea.setWrapStyleWord(true);
        JScrollPane cmdScroll = new JScrollPane(sqlCommandArea);
        cmdScroll.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
        cmdScroll.setBounds(5, 200, 968, 150);
        mainPanel.add(cmdScroll);

        // Execute and clear SQL command buttons
        styleButton(executeButton,  new Color(0, 160, 0),   Color.WHITE);
        styleButton(clearCmdButton, new Color(220, 220, 0), Color.BLACK);
        executeButton.setBounds(160, 358, 190, 26);
        clearCmdButton.setBounds(470, 358, 170, 26);
        mainPanel.add(executeButton);
        mainPanel.add(clearCmdButton);

        // SQL Execution Result Window
        JLabel resultLabel = new JLabel("SQL Execution Result Window", SwingConstants.CENTER);
        resultLabel.setFont(new Font("Arial", Font.BOLD, 12));
        resultLabel.setForeground(new Color(0, 100, 200));
        resultLabel.setBounds(5, 391, 968, 20);
        mainPanel.add(resultLabel);

        resultTable.setModel(emptyModel);
        resultTable.setEnabled(false);
        resultTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        resultTable.setGridColor(Color.BLACK);
        resultTable.setFont(new Font("Monospaced", Font.PLAIN, 12));
        resultTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        JScrollPane resultScroll = new JScrollPane(resultTable);
        resultScroll.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
        resultScroll.setBounds(5, 413, 968, 310);
        mainPanel.add(resultScroll);

        // Clear result window and close application buttons 
        styleButton(clearResultButton, new Color(220, 220, 0), Color.BLACK);
        styleButton(closeButton,       new Color(180, 0, 0),   Color.WHITE);
        clearResultButton.setBounds(5,   730, 190, 28);
        closeButton.setBounds(770, 730, 190, 28);
        mainPanel.add(clearResultButton);
        mainPanel.add(closeButton);

        getContentPane().add(mainPanel);
    }

    // Wire all of the button event handlers
	private void wireButtons() {

        // Connect
        connectButton.addActionListener(e -> {
            try {
                if (connection != null) { connection.close(); connection = null; }
                setStatus("  NO CONNECTION ESTABLISHED  ", false);

                // Load the hardcoded DB properties file (operationslog)
                Properties dbProps = loadProperties(OPERATIONSLOG_PROPS_FILE);

                // Load the hardcoded user properties file (theaccountant)
                Properties userProps = loadProperties(ACCOUNTANT_PROPS_FILE);

                // Load the JDBC driver
                Class.forName(dbProps.getProperty("MYSQL_DB_DRIVER_CLASS"));

                // Verify the credentials entered in the GUI against theaccountant.properties to see if they match
                String enteredUser = usernameField.getText().trim();
                String enteredPass = new String(passwordField.getPassword()).trim();
                String propsUser   = userProps.getProperty("MYSQL_DB_USERNAME");
                String propsPass   = userProps.getProperty("MYSQL_DB_PASSWORD");

                if (!enteredUser.equals(propsUser) || !enteredPass.equals(propsPass)) {
                    JOptionPane.showMessageDialog(this,
                        "Either the user-entered username and/or password does not match\n" +
                        "the credentials stored in the accountant properties file.\n" +
                        "No connection to the database has been established.",
                        "Connection Error – Credential Mismatch", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Establish the connection to operationslog
                MysqlDataSource ds = new MysqlDataSource();
                ds.setURL(dbProps.getProperty("MYSQL_DB_URL"));
                ds.setUser(propsUser);
                ds.setPassword(propsPass);
                connection = ds.getConnection();

                setStatus("  Connected to: " + dbProps.getProperty("MYSQL_DB_URL") + "  ", true);

            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this,
                    "MySQL driver not found.\n" + ex.getMessage(), "Driver Not Found", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Properties File Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Disconnect 
        disconnectButton.addActionListener(e -> {
            resultTable.setModel(emptyModel);
            try {
                if (connection != null) { connection.close(); connection = null; }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
            setStatus("  NO CONNECTION ESTABLISHED  ", false);
        });

        // Execute SQL Command (select only) 
        executeButton.addActionListener(e -> {
            if (connection == null) {
                JOptionPane.showMessageDialog(this,
                    "Not connected to a database.\nPlease connect first.",
                    "No Connection", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String sql = sqlCommandArea.getText().trim();
            if (sql.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a SQL command.",
                    "Empty Command", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Accountant can only run select queries
            if (!sql.toUpperCase().replaceAll("^[\\s(]+", "").startsWith("SELECT")) {
                JOptionPane.showMessageDialog(this,
                    "The Accountant application only supports SELECT queries.\n" +
                    "Update commands are not permitted.",
                    "Permission Denied", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                PreparedStatement ps = connection.prepareStatement(
                    sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                ResultSet rs = ps.executeQuery();
                ResultSetMetaData rsmd = rs.getMetaData();
                int cols = rsmd.getColumnCount();

                String[] colNames = new String[cols];
                for (int i = 1; i <= cols; i++) colNames[i - 1] = rsmd.getColumnName(i);

                java.util.List<Object[]> rowList = new java.util.ArrayList<>();
                while (rs.next()) {
                    Object[] row = new Object[cols];
                    for (int i = 1; i <= cols; i++) row[i - 1] = rs.getObject(i);
                    rowList.add(row);
                }
                rs.close(); ps.close();

                DefaultTableModel dtm = new DefaultTableModel(colNames, 0) {
                    public boolean isCellEditable(int r, int c) { return false; }
                };
                for (Object[] row : rowList) dtm.addRow(row);
                resultTable.setModel(dtm);
                autoResizeColumns(resultTable);

                // Reminder Isabel: Accountant operations are not logged to operationscount

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "SQL Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Clear SQL command
        clearCmdButton.addActionListener(e -> sqlCommandArea.setText(""));

        // Clear result window 
        clearResultButton.addActionListener(e -> resultTable.setModel(emptyModel));

        // Close application 
        closeButton.addActionListener(e -> {
            try { if (connection != null) connection.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            System.exit(0);
        });
    }

    // Expands each column to fit its content
    private void autoResizeColumns(JTable table) {
        for (int col = 0; col < table.getColumnCount(); col++) {
            int maxWidth = 50;

            javax.swing.table.TableCellRenderer headerRenderer =
                table.getTableHeader().getDefaultRenderer();
            java.awt.Component headerComp = headerRenderer.getTableCellRendererComponent(
                table, table.getColumnName(col), false, false, 0, col);
            maxWidth = Math.max(maxWidth, headerComp.getPreferredSize().width + 10);

            for (int row = 0; row < table.getRowCount(); row++) {
                javax.swing.table.TableCellRenderer cellRenderer =
                    table.getCellRenderer(row, col);
                java.awt.Component cellComp = table.prepareRenderer(cellRenderer, row, col);
                maxWidth = Math.max(maxWidth, cellComp.getPreferredSize().width + 10);
            }

            maxWidth = Math.min(maxWidth, 400);
            table.getColumnModel().getColumn(col).setPreferredWidth(maxWidth);
        }
    }

    // Helper, load a properties file from the project root
    private Properties loadProperties(String filename) throws IOException {
        Properties props = new Properties();
        FileInputStream fis = new FileInputStream(filename);
        props.load(fis);
        fis.close();
        return props;
    }

    // Helper, update the connection status label
    private void setStatus(String text, boolean connected) {
        connectionStatusLabel.setText(text);
        connectionStatusLabel.setBackground(connected ? new Color(0, 130, 0) : new Color(160, 0, 0));
    }

    // Helper, apply consistent button styling throughout it all
    private void styleButton(JButton btn, Color bg, Color fg) {
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
    }

    // Main
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TheAccountantApp());
    }
} 
